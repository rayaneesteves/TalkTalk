
package control;

import model.Clientes;
import dao.ClienteServiço;

public class Usercontrol {
    ClienteServiço servicos;
    
    public boolean GravandoUser(Clientes dados){
        servicos = new ClienteServiço();
        return servicos.SalvarClientes(dados);
    }
    public boolean EmailControl(String email){
        servicos = new ClienteServiço();
        return servicos.VerificaEmailCliente(email);
    }
    
     public boolean SenhaControl(String senha){
        servicos = new ClienteServiço();
        return servicos.VerificaSenhaCliente(senha);
    }
     
      public String RetornaNome(String email){
        servicos = new ClienteServiço();
        return servicos.RetornaNome(email);
    }
      
       public boolean atualizandoStatusUsuario(int status, String email){
        servicos = new ClienteServiço();
        return servicos.UpdateStatus(status, email);
    }
}
