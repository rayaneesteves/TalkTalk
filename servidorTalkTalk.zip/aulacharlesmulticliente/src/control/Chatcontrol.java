package control;

import talktalk.Mensagem;
import dao.ConversinhasServiço;
import java.util.ArrayList;
import java.util.List;

public class Chatcontrol {

    private ConversinhasServiço chat;

    public List<Mensagem> ListandoMensagensPriv() {
        chat = new ConversinhasServiço();
        return chat.MostrarPrivado();
    }

    public ArrayList<String> ListandoUsuarios() {
        chat = new ConversinhasServiço();
        return chat.ListaUsuario();
    }

    public ArrayList<Mensagem> GravandoMensagemPv(Mensagem mensagens) {
        chat = new ConversinhasServiço();
        return chat.GravarPrivado(mensagens);
    }

    public ArrayList<Mensagem> GravandoMensagemGeral(Mensagem mensagens) {
        chat = new ConversinhasServiço();
        return chat.GravarGeral(mensagens);
    }

    public List<Mensagem> TabelaPrivada(Mensagem mensagens) {
        chat = new ConversinhasServiço();
        return chat.tabelaPrivada(mensagens);
    }

    public ArrayList<Mensagem> TabelaAberta(Mensagem mensagens) {
        chat = new ConversinhasServiço();
        return chat.TabelaGeral(mensagens);
    }
}
