package talktalk;

import control.Chatcontrol;
import control.Usercontrol;
import dao.ConversinhasServiço;
import model.Clientes;
import java.sql.Connection;
import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public class TrataCliente implements Runnable {

    private Socket soquete_cliente;
    private ObjectOutputStream saida;
    private ObjectInputStream entrada;
    private List<Mensagem> mensagens;
    private List<Mensagem> usuarios;
    private String Loginnome = "";

    private Chatcontrol controleChat = new Chatcontrol();
    private Usercontrol controleUsuario = new Usercontrol();

    public TrataCliente(Socket soquete_cliente) throws Exception {
        super();
        this.soquete_cliente = soquete_cliente;
        this.saida = new ObjectOutputStream(this.soquete_cliente.getOutputStream());
        this.entrada = new ObjectInputStream(this.soquete_cliente.getInputStream());

    }

    public void enviar_mensagem(Object mensagem) throws Exception {
        this.saida.writeObject(mensagem);

    }

    public Object receber_mensagem() throws Exception {
        return this.entrada.readObject();
    }

    public void finalizar() throws IOException {
        this.soquete_cliente.close();
    }

    @Override
    public void run() {

        String nomeusuario = " ";
controleChat = new Chatcontrol();
        try {
            Mensagem mensagem;

  
            mensagem = (Mensagem) receber_mensagem();
           
            if (mensagem.getMensagem().equals("Cadastrar")) {

                while (controleUsuario.EmailControl(mensagem.getEmail()) == true) {

                    enviar_mensagem("Esse email ja esta sendo utilizado");
                    String email = (String) receber_mensagem();
                    mensagem.setEmail(email);
                }

                String email = mensagem.getEmail();
                String senha = mensagem.getSenha();
                String nome = mensagem.getNome();
                int status = 1;
                Clientes repassavalores = new Clientes();
                repassavalores.setNome(nome);
                repassavalores.setEmail(email);
                repassavalores.setSenha(senha);
                repassavalores.setStatus(status);
                nomeusuario = nome;
                if (controleUsuario.GravandoUser(repassavalores) == true) {
                    enviar_mensagem("cadastro feito com sucesso");
                    controleUsuario.atualizandoStatusUsuario(status, repassavalores.getEmail());

                }

            }
            if (mensagem.getMensagem().equals("Logar")) {
                if (controleUsuario.EmailControl(mensagem.getEmail()) == true && (controleUsuario.SenhaControl(mensagem.getSenha()) == true)) {
                    int estado = 1;
                    //mandando o nome do usuario pro usuario
                    enviar_mensagem("Login feito com sucesso");
                    enviar_mensagem(controleUsuario.RetornaNome(mensagem.getEmail()));

                    controleUsuario.atualizandoStatusUsuario(estado, mensagem.getEmail());
                } else {
                    enviar_mensagem("Login errado");

                }
            }
            if (mensagem.getMensagem().equals("Listar")) {
                enviar_mensagem(controleChat.ListandoUsuarios());
                
            }
            if (mensagem.getMensagem().equals("GravarPv")) {

                //recebendo o nome do cara que vai mandar mensagem
                Mensagem usuarioselecionado = (Mensagem) receber_mensagem();
                //enviando tudo que está gravado
                enviar_mensagem(controleChat.GravandoMensagemPv(usuarioselecionado));

            }
            if (mensagem.getMensagem().equals("AtualizaPv")) {
                //enviando tudo que está gravado
              
                enviar_mensagem(controleChat.TabelaPrivada(mensagem));
               
            }

            if (mensagem.getMensagem().equals("GravarGeral")) {
                Mensagem textochat = (Mensagem) receber_mensagem();
              
                enviar_mensagem(controleChat.GravandoMensagemGeral(textochat));

            }
            if (mensagem.getMensagem().equals("MostraChat")) {
             
                enviar_mensagem(controleChat.TabelaAberta(mensagem));

            }

            if (mensagem.getMensagem().equals("Sair")) {
                String estadosair;
                estadosair = (String) receber_mensagem();
                int status = 0;
               if(estadosair.equalsIgnoreCase("estou saindo"))
                controleUsuario.atualizandoStatusUsuario(status, mensagem.getEmail());
            }

        } catch (Exception e) {
            e.printStackTrace();

        }

    }

}
