package talktalk;

import java.io.Serializable;

public class Mensagem implements Serializable {

    private String email;
    private String Mensagem;
    private String senha;
    private String nome;
    private String Destinatario;
    private String Remetente;

    public Mensagem(String email, String Mensagem, String senha, String nome) {
        this.email = email;
        this.Mensagem = Mensagem;
        this.senha = senha;
        this.nome = nome;
    }

    public Mensagem(String Remetente, String Mensagem, String Destinatario) {
        this.Remetente = Remetente;
        this.Mensagem = Mensagem;
        this.Destinatario = Destinatario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMensagem() {
        return Mensagem;
    }

    public void setMensagem(String Mensagem) {
        this.Mensagem = Mensagem;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDestinatario() {
        return Destinatario;
    }

    public void setDestinatario(String Destinatario) {
        this.Destinatario = Destinatario;
    }

    public String getRemetente() {
        return Remetente;
    }

    public void setRemetente(String Remetente) {
        this.Remetente = Remetente;
    }

   
    @Override

    public String toString() {
        return "Mensagem{" + "email=" + email + ", texto=" + Mensagem + ", senha=" + senha + ", nome=" + nome + '}';
    }

}
