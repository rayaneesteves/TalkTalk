package dao;

import tools.Conexao;
import model.Clientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClienteServiço {

    public boolean VerificaEmailCliente(String email) {

        try {
            Connection Connect = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM talktalk.cliente WHERE email = ?";
            PreparedStatement consulta = Connect.prepareStatement(sql);
            consulta.setString(1, email);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                Connect.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteServiço.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false; //retorna false se nao existir
    }

    public boolean VerificaSenhaCliente(String senha) {

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM talktalk.cliente WHERE senha = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, senha);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteServiço.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false; //retorna false se nao existir
    }

    public String RetornaNome(String email) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome FROM talktalk.cliente WHERE email = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String nome = resultado.getString("nome");
                c.close();
                return nome;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteServiço.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }

    public boolean SalvarClientes(Clientes dados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO talktalk.cliente(nome,email,senha) "
                    + " VALUES (?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, dados.getNome());
            insercao.setString(2, dados.getEmail());
            insercao.setString(3, dados.getSenha());
            insercao.executeUpdate();

            c.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteServiço.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
        return false;
    }

    public boolean UpdateStatus(int status, String email) {

        try {
            Connection c = Conexao.obeterConexao();

            String sql = "UPDATE talktalk.cliente SET status = ? WHERE email = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            atualizacao.setInt(1, status);
            atualizacao.setString(2, email);

            int Afetado = atualizacao.executeUpdate();

            if (Afetado > 0) {
                return true;
            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClienteServiço.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}