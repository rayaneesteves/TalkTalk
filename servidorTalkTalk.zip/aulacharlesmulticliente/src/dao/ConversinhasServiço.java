package dao;

import tools.Conexao;
import model.Clientes;
import talktalk.Mensagem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ConversinhasServiço {

    public List<Mensagem> MostrarPrivado() {
        List<Mensagem> nomes = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome FROM talktalk.cliente"; 
            PreparedStatement consulta = c.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                String nome = resultado.getString("nome");
                String senha = resultado.getString("senha");
                String email = resultado.getString("email");
                String mensagem = resultado.getString("mensagem");
                Mensagem adicionaelemt = new Mensagem(email, mensagem, senha, nome);
                nomes.add(adicionaelemt);
            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConversinhasServiço.class.getName()).log(Level.SEVERE, null, ex);
        }

        return nomes;
    }

    public ArrayList<Mensagem> GravarPrivado(Mensagem mensagens) {
        ArrayList<Mensagem> listaMensagens = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO talktalk.mensagempv(mensagem,destinatario,remetente)"
                    + " VALUES (?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, mensagens.getMensagem());
            insercao.setString(2, mensagens.getDestinatario()); //destinatario
            insercao.setString(3, mensagens.getRemetente()); //remetente
            insercao.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ConversinhasServiço.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaMensagens;

    }

    public ArrayList<Mensagem> GravarGeral(Mensagem mensagens) {
        ArrayList<Mensagem> ListaMensagemGeral = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO talktalk.mensagemgeral(mensagem,usuario)"
                    + " VALUES (?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, mensagens.getMensagem()); //mensagem
            insercao.setString(2, mensagens.getRemetente());//nome de quem enviou
            
            insercao.executeUpdate();

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConversinhasServiço.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ListaMensagemGeral;
    }

    public List<Mensagem> tabelaPrivada(Mensagem mensagens) {
        List<Mensagem> mensagensPrivadas = new ArrayList<>();
        
        String sql = "SELECT remetente, mensagem, destinatario FROM talktalk.mensagempv WHERE (destinatario = ? AND remetente = ?) OR (remetente = ? AND destinatario = ?)  ";

        try {
            Connection c = Conexao.obeterConexao();
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, mensagens.getDestinatario());
            ps.setString(2, mensagens.getRemetente());
            ps.setString(3, mensagens.getDestinatario());
            ps.setString(4, mensagens.getRemetente());
           
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Mensagem atual = new Mensagem(mensagens.getNome(), mensagens.getMensagem(), mensagens.getDestinatario());
                atual.setDestinatario(rs.getString("destinatario"));
                atual.setMensagem(rs.getString("mensagem"));
                atual.setRemetente(rs.getString("remetente"));

                mensagensPrivadas.add(atual);
            }
            c.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao retornar mensagens do chat: " + ex.getMessage());
        }

        return mensagensPrivadas;
    }

    public ArrayList<Mensagem> TabelaGeral(Mensagem mensagens) {
        ArrayList<Mensagem> mensagensPrivadas = new ArrayList<>();

        try {
            Connection Connect = Conexao.obeterConexao();
            String sql = "SELECT mensagem,usuario FROM talktalk.mensagemGeral;";
            PreparedStatement Result = Connect.prepareStatement(sql);

            ResultSet resultado = Result.executeQuery();

            while (resultado.next()) {
                Mensagem atual = new Mensagem(mensagens.getEmail(), mensagens.getMensagem(), mensagens.getSenha(), mensagens.getNome());
                atual.setMensagem(resultado.getString("mensagem"));
              
                atual.setRemetente(resultado.getString("usuario"));
                
                mensagensPrivadas.add(atual);
            }

            Connect.close();
        } catch (SQLException ex) {
           System.out.println("Erro ao retornar mensagens do chat: " + ex.getMessage());
        }

        return mensagensPrivadas;
    }

    public ArrayList<String> ListaUsuario() {
        ArrayList<String> ListaCliente = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();

            String sql = "SELECT nome FROM talktalk.cliente WHERE status = 1 ORDER BY nome ASC;";
            PreparedStatement trans = c.prepareStatement(sql);
            ResultSet resultadoBD = trans.executeQuery();

            while (resultadoBD.next()) {
                String nome = resultadoBD.getString("nome");
                if (ListaCliente.contains(nome)) {

                } else {
                    ListaCliente.add(nome);
                }
            }
            return ListaCliente;

        } catch (SQLException ex) {
            System.err.println("Erro ao listar Clientes");
            ex.printStackTrace();
            return null;
        }
    }

}
