package view;

import talktalk.Cliente;
import talktalk.Mensagem;
import talktalk.usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.SwingWorker;

public class Tela_Privada extends javax.swing.JFrame {

    private Cliente cliente = null;
    usuarios Dados;
    Mensagem Destino;

    public Tela_Privada(Mensagem selecionada, usuarios dadosUsuario) {
        initComponents();
        downloadBackground();
        this.setLocationRelativeTo(null);

        Dados = dadosUsuario;
        Destino = selecionada;
        nomeUsuarioLbl.setText(Destino.getDestinatario());

        AtualizaConversinhas();  //--> objetivo dele: atualizar o list de mensagens...
    }

    public Tela_Privada() {
        initComponents();
        downloadBackground();
        this.setLocationRelativeTo(null);
        AtualizaConversinhas();
    }

    private void downloadBackground() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\sources\\telaChat.jpg"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1070, 600, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(Tela_Privada.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        sair = new javax.swing.JButton();
        nomeUsuarioLbl = new javax.swing.JLabel();
        enviar = new javax.swing.JButton();
        txtMensage = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        listMsg = new javax.swing.JList<>();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel1.setPreferredSize(new java.awt.Dimension(1068, 601));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("Voltar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 20, 80, 30));

        sair.setText("Sair");
        sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairActionPerformed(evt);
            }
        });
        jPanel1.add(sair, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 20, -1, 30));

        nomeUsuarioLbl.setFont(new java.awt.Font("DialogInput", 1, 14)); // NOI18N
        nomeUsuarioLbl.setForeground(new java.awt.Color(51, 153, 255));
        jPanel1.add(nomeUsuarioLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 240, 30));

        enviar.setText("Enviar");
        enviar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                enviarMousePressed(evt);
            }
        });
        enviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enviarActionPerformed(evt);
            }
        });
        jPanel1.add(enviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 460, -1, -1));

        txtMensage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMensageActionPerformed(evt);
            }
        });
        jPanel1.add(txtMensage, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, 710, -1));

        jScrollPane1.setViewportView(listMsg);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 790, 370));
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 600));
        fotofundo.getAccessibleContext().setAccessibleDescription("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void AtualizaConversinhas() {
        SwingWorker pessoasOnline = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                while (true) {
                    cliente = new Cliente("10.90.36.46", 15500);
                    
                    cliente.enviar_mensagem(new Mensagem(Dados.getNome(), "AtualizaPv", Destino.getDestinatario()));
                    List<Mensagem> listaDeMensagens = (List<Mensagem>) cliente.receber_mensagem();

                    DefaultListModel dlm = new DefaultListModel();
                    dlm.addAll(listaDeMensagens);
                    listMsg.setModel(dlm);
                }
            }
        };
        pessoasOnline.execute();
    }
    
    private void enviarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_enviarMousePressed
        //quando eu enviar eu tenho que falar pro servidor enviar minha mensagem...
        String mensagemEnviar = txtMensage.getText();
        txtMensage.setText("");
        try {
            cliente = new Cliente("10.90.36.46", 15500);
            cliente.enviar_mensagem(new Mensagem(Dados.getEmail(), "GravarPv", Dados.getNome(), Dados.getSenha()));
            //enviando a mensagem...
            cliente.enviar_mensagem(new Mensagem(Dados.getNome(), mensagemEnviar, Destino.getDestinatario()));
        } catch (Exception ex) {
            Logger.getLogger(Tela_Privada.class.getName()).log(Level.SEVERE, null, ex);
        }
        AtualizaConversinhas();  //--> objetivo dele: atualizar o list de mensagens...
    }//GEN-LAST:event_enviarMousePressed

    private void sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairActionPerformed
       try {
            // TODO add your handling code here:
            cliente = new Cliente("10.90.36.46", 15500);
            cliente.enviar_mensagem(new Mensagem(Dados.getEmail(), "Sair", Dados.getNome(), Dados.getSenha()));
            
                cliente.enviar_mensagem("estou saindo");
                cliente.finalizar();
                dispose();
        } catch (Exception ex) {
            Logger.getLogger(Tela_Privada.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_sairActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void txtMensageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMensageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMensageActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Tela_Geral redirecionar = new Tela_Geral(Dados);
            redirecionar.setVisible(true);
            dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void enviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enviarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enviarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tela_Privada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tela_Privada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tela_Privada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tela_Privada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tela_Privada().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton enviar;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listMsg;
    private javax.swing.JLabel nomeUsuarioLbl;
    private javax.swing.JButton sair;
    private javax.swing.JTextField txtMensage;
    // End of variables declaration//GEN-END:variables
}
