package view;

import talktalk.Cliente;
import talktalk.Mensagem;
import talktalk.usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Tela_Login extends javax.swing.JFrame {

    Cliente cliente = null;
    private usuarios dadosEnviar;
    public Tela_Login() {
        initComponents();
        this.setLocationRelativeTo(null);
        downloadBackground();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtEmail = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        logarBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setMinimumSize(new java.awt.Dimension(720, 605));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtEmail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, 190, 20));

        txtSenha.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 290, 190, -1));

        logarBtn.setBackground(new java.awt.Color(0, 153, 204));
        logarBtn.setForeground(new java.awt.Color(255, 255, 51));
        logarBtn.setText("Logar");
        logarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logarBtnActionPerformed(evt);
            }
        });
        jPanel1.add(logarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 350, 80, 30));

        jLabel2.setForeground(new java.awt.Color(153, 102, 255));
        jLabel2.setText("Cadastrar");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel2MousePressed(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 380, 70, -1));
        jPanel1.add(fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 410));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void logarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logarBtnActionPerformed
        try {
            cliente = new Cliente("10.90.36.46", 15500);
            String email = txtEmail.getText();
            String senha = (new String(txtSenha.getPassword()));
            cliente.enviar_mensagem(new Mensagem(email, "Logar", senha, ""));
            dadosEnviar = new usuarios();
            dadosEnviar.setEmail(email);
            dadosEnviar.setSenha(senha);
            String mensagem = (String) cliente.receber_mensagem();
            if (mensagem.equalsIgnoreCase("Login feito com sucesso")) {
               String mensagemNome = (String) cliente.receber_mensagem();
                
                dadosEnviar.setNome(mensagemNome);
                
                JOptionPane.showMessageDialog(null, "Login certo!", "Bem-vindo(a)!", JOptionPane.INFORMATION_MESSAGE);
                Tela_Geral redirecionar = new Tela_Geral(dadosEnviar);
                redirecionar.setVisible(true);
                dispose();
            }else{
            if (mensagem.equalsIgnoreCase("Login errado")) 
                JOptionPane.showMessageDialog(null, "Login errado!", "ERRO!", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            Logger.getLogger(Tela_Login.class.getName()).log(Level.SEVERE, null, ex);
            
        }


    }//GEN-LAST:event_logarBtnActionPerformed

    private void jLabel2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MousePressed

        Tela_Cadastro redirecionar = new Tela_Cadastro();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel2MousePressed
    private void downloadBackground() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\sources\\telaLogin2.jpg"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(720, 410, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(Tela_Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void logando() {
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tela_Login().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel fundo;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton logarBtn;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
