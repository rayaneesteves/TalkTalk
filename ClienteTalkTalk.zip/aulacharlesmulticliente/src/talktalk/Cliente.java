package talktalk;

import java.net.Socket;
import java.util.ArrayList;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Cliente {

    private Socket soquete;
    private ObjectOutputStream saida;
    private ObjectInputStream entrada;
    public ArrayList<Mensagem> mensagens;

    public Cliente(String endereco, int porta) throws Exception {
        super();
        this.soquete = new Socket(endereco, porta);
        this.saida = new ObjectOutputStream(this.soquete.getOutputStream());
        this.entrada = new ObjectInputStream(this.soquete.getInputStream());
    }

    public void enviar_mensagem(Object mensagem) throws Exception {
        this.saida.writeObject(mensagem);
    }

    public Object receber_mensagem() throws Exception {
        return this.entrada.readObject();
    }

    public void finalizar() throws IOException {
        this.soquete.close();
    }

    public static void main(String[] args) throws Exception {
        Scanner entrada = new Scanner(System.in);

        Cliente cliente = null;
        int op;
        int cont = 0;
        String nome = "";

        do {
            System.out.print("1:Conectar\n");
            System.out.print("2:Desconectar\n");
            System.out.print("3:Listar usuarios\n");
            System.out.print("4:Listar Mensagem Geral\n");
            System.out.print("5:Enviar Mensagem\n");
            System.out.print("5:Enviar Mensagem Específica\n");
            System.out.print("6:Listar Mensagens Específicas\n");

            op = entrada.nextInt();
            while (op == 1 && cont == 1) {
                System.err.print("\n\nCliente já conectado\n\n");
                System.out.print("\n2:Desconectar");
                System.out.print("\n3:Listar usuarios");
                System.out.print("\n4:Listar Mensagem Geral");
                System.out.print("\n5:Enviar Mensagem Específica");
                System.out.print("\n6:Listar Mensagens Específicas");
                op = entrada.nextInt();
            }

            switch (op) {

                case 1:
                    cliente = new Cliente("10.90.37.110", 15500);
                    System.out.println("Digite seu nome: ");
                    entrada.skip("\n");
                    nome = entrada.nextLine();
                    String mensagemerro =(String)cliente.receber_mensagem();
                    
                   if(mensagemerro.equalsIgnoreCase("Nome ja cadastrado")){
                   
                     System.out.println(cliente.receber_mensagem());
                     System.out.println(cliente.receber_mensagem());
                     String opnome = entrada.nextLine();
                     cliente.enviar_mensagem(opnome);
                 }
                    cont = 1;
                    break;

                case 2:
                    System.out.println(cliente.receber_mensagem());
                    cliente.finalizar();
                    break;

                case 3:
                    //cliente.enviar_mensagem(new Mensagem(nome, "3"));
                    System.out.println("Usuarios online:");
                    cliente.mensagens = (ArrayList<Mensagem>) cliente.receber_mensagem();
                    System.out.println(cliente.mensagens);
                    break;

                case 4:
                    //cliente.enviar_mensagem(new Mensagem(nome, "4"));
                    System.out.println(cliente.receber_mensagem());
                    break;

                case 5:
                   //cliente.enviar_mensagem(new Mensagem(nome, "5"));
                    System.out.println("Escolha um usuário para enviar a mensagem:");
                    System.out.println(cliente.receber_mensagem());
                    entrada.skip("\n");
                    String usuario = entrada.nextLine();
                    
                   //cliente.enviar_mensagem(new Mensagem(nome, usuario));
                    System.out.println(cliente.receber_mensagem());
                    System.out.println("teste 0");
                    entrada.skip("\n");
                    
                    //escrevendo mensagem
                    String mensagemDeEnvio = entrada.nextLine();
                    System.out.println("teste 1");
                    
                   // cliente.enviar_mensagem(new Mensagem(nome, mensagemDeEnvio));
                    System.out.println("teste 2");
                    System.out.println(cliente.receber_mensagem());
                    break;
            }

        } while (op != 2);
        
    }
}
